package com.axyya.flightapplication.repository;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.axyya.flightapplication.entity.Flight;

class FlightRepositotyTest {

	
		@Autowired
		private FlightRepository flightRepo;

		@Test
		public void findFlights() {
			Flight f=new Flight("AIR-ASIA",250,"London","UK");
			flightRepo.save(f);
			
		}
	}

