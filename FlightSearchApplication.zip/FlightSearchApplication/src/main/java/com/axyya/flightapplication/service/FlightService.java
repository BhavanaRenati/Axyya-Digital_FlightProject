package com.axyya.flightapplication.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.axyya.flightapplication.entity.Flight;
import com.axyya.flightapplication.repository.FlightRepository;

@Service
public class FlightService {
	
	@Autowired
	private FlightRepository flightRepo;

	@SuppressWarnings("unchecked")
	public ResponseEntity<List<Flight>> searchflight(String flightName,String from, String to) throws Exception {
		
		List<Flight> searchflightResults = flightRepo.searchflight(flightName,from, to);
		
		System.out.println(searchflightResults);
		if(!searchflightResults.isEmpty()) {
			
				return new ResponseEntity(searchflightResults,HttpStatus.OK) ;

			
		}else {
			return  new ResponseEntity("Flights not Found....",HttpStatus.OK) ;
		}

}
}