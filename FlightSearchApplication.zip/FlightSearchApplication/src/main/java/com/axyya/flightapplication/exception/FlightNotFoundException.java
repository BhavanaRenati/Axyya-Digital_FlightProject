package com.axyya.flightapplication.exception;

public class FlightNotFoundException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = -1240310375491018781L;

	public FlightNotFoundException(String customMessage) {
		super(customMessage);
	}
	public FlightNotFoundException() {
		super();
	}

}
