package com.axyya.flightapplication.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.axyya.flightapplication.entity.Flight;

public interface FlightRepository extends JpaRepository<Flight, Integer> {
	
	
	@Query("from Flight where carrierName=:flightName and source=:from and destination=:to")
	List<Flight> searchflight(@Param("flightName") String flightName, @Param("from") String from,@Param("to") String to);
	
}
	

