package com.axyya.flightapplication.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.axyya.flightapplication.dto.FlightDto;
import com.axyya.flightapplication.entity.Flight;
import com.axyya.flightapplication.service.FlightService;

@RestController
public class FlightController {

	@Autowired
	private FlightService flightService;

	@GetMapping("/findFlights")
	public ResponseEntity<List<Flight>> findFlights(@RequestBody FlightDto flightDto) throws Exception {
		String flightName = flightDto.getFlightName();
		String from = flightDto.getFrom();
		String to = flightDto.getTo();
		ResponseEntity<List<Flight>> searchflightResults = flightService.searchflight(flightName, from, to);
		return searchflightResults;
	}

}