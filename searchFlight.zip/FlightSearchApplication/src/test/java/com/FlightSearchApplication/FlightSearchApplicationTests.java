package com.FlightSearchApplication;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.annotation.Rollback;

import com.FlightSearchApplication.entity.Flight;
import com.FlightSearchApplication.repository.FlightRepository;


@DataJpaTest
@AutoConfigureTestDatabase(replace=Replace.NONE)
@Rollback(false)
class FlightSearchApplicationTests {
	
	@Autowired
	private FlightRepository flightRepo;

	@Test
	public void findFlights() {
		Flight f=new Flight("AIR-ASIA",250,"London","UK");
		flightRepo.save(f);
		
	}

}
