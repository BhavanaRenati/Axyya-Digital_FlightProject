package com.FlightSearchApplication.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.FlightSearchApplication.entity.Flight;

public interface FlightRepository extends JpaRepository<Flight, Integer> {
	
	@Query("from Flight where source=:from and destination=:to")
	List<Flight> searchflight(@Param("from") String from,@Param("to") String to);

}
