package com.FlightSearchApplication.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.FlightSearchApplication.entity.Flight;
import com.FlightSearchApplication.repository.FlightRepository;

@Service
public class FlightService {
	
	@Autowired
	private FlightRepository flightRepo;
	
	public void findFlights(Flight flight) {
		flightRepo.save(flight);
		
	}

	public List<Flight> searchflight(String from, String to) {
		
		List<Flight> searchflightResults = flightRepo.searchflight(from, to);
		if(searchflightResults)
		return searchflightResults;
		
	}

}
