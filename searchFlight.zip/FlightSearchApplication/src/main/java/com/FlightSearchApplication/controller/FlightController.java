package com.FlightSearchApplication.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.FlightSearchApplication.dto.FlightDto;
import com.FlightSearchApplication.entity.Flight;
import com.FlightSearchApplication.repository.FlightRepository;
import com.FlightSearchApplication.service.FlightService;

@RestController
public class FlightController {
	
		@Autowired
		private FlightService flightService;
		
		@GetMapping("/findFlights")
		public List<Flight> findFlights(@RequestBody FlightDto flightDto ) {
			String from=flightDto.getFrom();
			String to=flightDto.getTo();
			List<Flight> searchflightResults = flightService.searchflight(from,to);
			return  searchflightResults;
		}
		
	}

